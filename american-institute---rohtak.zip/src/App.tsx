/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { 
  BookOpen, 
  CheckCircle2, 
  Clock, 
  GraduationCap, 
  Mail, 
  MapPin, 
  MessageCircle, 
  Phone, 
  Users, 
  Zap, 
  Award,
  Globe,
  Star,
  ChevronRight,
  Menu,
  X,
  Download,
  Copy
} from 'lucide-react';
import { motion, AnimatePresence, useScroll, useSpring, useReducedMotion } from 'motion/react';
import { useState, useEffect, ChangeEvent, useRef } from 'react';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';
import { auth, signInWithGoogle, db } from './lib/firebase';
import { onAuthStateChanged, User, signOut } from 'firebase/auth';
import { doc, getDoc, setDoc, updateDoc, serverTimestamp } from 'firebase/firestore';

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);
  
  // High performance animations for smooth experience
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, { stiffness: 100, damping: 30, restDelta: 0.001 });
  const prefersReducedMotion = useReducedMotion();

  // E-Card State
  const [studentData, setStudentData] = useState({
    name: '',
    course: 'Spoken English',
    idType: 'Aadhaar' as 'Aadhaar' | 'PAN',
    idNumber: '',
    uniqueId: '',
    photo: '',
    isPaid: false
  });

  // Course Payment State
  const [coursePaymentConfig, setCoursePaymentConfig] = useState({
    showDialog: false,
    selectedCourse: null as any | null,
    amount: '1500',
    transactionId: '',
    isVerifying: false,
    verified: false,
    copied: false
  });

  const [errors, setErrors] = useState({
    idNumber: ''
  });

  // Auth & Firestore Sync
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      setAuthLoading(false);
      
      if (user) {
        // Fetch existing data from Firestore
        try {
          const docRef = doc(db, 'students', user.uid);
          let docSnap;
          
          try {
            docSnap = await getDoc(docRef);
          } catch (fetchError: any) {
            console.error("Firestore fetch error:", fetchError);
            
            // If it fails with "offline" or "unavailable", wait and try once more
            if (fetchError.code === 'unavailable' || fetchError.message?.includes('offline')) {
              console.warn("Firestore appears offline, retrying in 3s...");
              await new Promise(r => setTimeout(r, 3000));
              try {
                docSnap = await getDoc(docRef);
              } catch (retryError) {
                console.error("Retry failed:", retryError);
                throw retryError;
              }
            } else {
              throw fetchError;
            }
          }
          
          if (docSnap && docSnap.exists()) {
            setStudentData(docSnap.data() as any);
          } else {
            // Pre-fill with user info
            setStudentData(prev => ({
              ...prev,
              name: user.displayName || '',
              email: user.email || ''
            }));
          }
        } catch (error) {
          console.error("Error fetching student data:", error);
          // Set defaults even on error to let user interact
          setStudentData(prev => ({
            ...prev,
            name: user.displayName || '',
            email: user.email || ''
          }));
        }
      } else {
        // Reset state on logout
        setStudentData({
          name: '',
          email: '',
          course: 'Spoken English',
          idType: 'Aadhaar' as 'Aadhaar' | 'PAN',
          idNumber: '',
          uniqueId: '',
          photo: '',
          isPaid: false
        });
      }
    });
    return () => unsubscribe();
  }, []);

  const handleSignIn = async () => {
    try {
      await signInWithGoogle();
    } catch (error) {
      console.error(error);
    }
  };

  const handleSignOut = async () => {
    try {
      await signOut(auth);
    } catch (error) {
      console.error(error);
    }
  };

  // Verhoeff Algorithm for Aadhaar Validation
  const validateAadhaar = (aadhaar: string) => {
    if (!/^\d{12}$/.test(aadhaar)) return false;
    
    // Aadhaar shouldn't start with 0 or 1
    if (aadhaar[0] === '0' || aadhaar[0] === '1') return false;

    const d = [
      [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
      [1, 2, 3, 4, 0, 6, 7, 8, 9, 5],
      [2, 3, 4, 0, 1, 7, 8, 9, 5, 6],
      [3, 4, 0, 1, 2, 8, 9, 5, 6, 7],
      [4, 0, 1, 2, 3, 9, 5, 6, 7, 8],
      [5, 9, 8, 7, 6, 0, 4, 3, 2, 1],
      [6, 5, 9, 8, 7, 1, 0, 4, 3, 2],
      [7, 6, 5, 9, 8, 2, 1, 0, 4, 3],
      [8, 7, 6, 5, 9, 3, 2, 1, 0, 4],
      [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
    ];
    const p = [
      [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
      [1, 5, 7, 6, 2, 8, 3, 0, 9, 4],
      [5, 8, 0, 3, 7, 9, 6, 1, 4, 2],
      [8, 9, 1, 6, 0, 4, 3, 5, 2, 7],
      [9, 4, 5, 3, 1, 2, 6, 8, 7, 0],
      [4, 2, 8, 6, 5, 7, 3, 9, 0, 1],
      [2, 7, 9, 3, 8, 0, 6, 4, 1, 5],
      [7, 0, 4, 6, 9, 1, 3, 2, 5, 8]
    ];
    const inv = [0, 4, 3, 2, 1, 5, 6, 7, 8, 9];

    let c = 0;
    const invertedArray = aadhaar.split('').map(Number).reverse();

    for (let i = 0; i < invertedArray.length; i++) {
      c = d[c][p[i % 8][invertedArray[i]]];
    }

    return c === 0;
  };

  const validatePAN = (val: string) => /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/.test(val.toUpperCase());

  const handleIdNumberChange = (val: string) => {
    setStudentData(prev => ({ ...prev, idNumber: val.toUpperCase() }));
    
    if (val === '') {
      setErrors(prev => ({ ...prev, idNumber: '' }));
      return;
    }

    let isValid = false;
    if (studentData.idType === 'Aadhaar') {
      isValid = validateAadhaar(val);
      setErrors(prev => ({ 
        ...prev, 
        idNumber: isValid ? '' : 'Invalid Aadhaar Number (Verification Failed)' 
      }));
    } else {
      isValid = validatePAN(val);
      setErrors(prev => ({ 
        ...prev, 
        idNumber: isValid ? '' : 'Invalid PAN format (e.g. ABCDE1234F)' 
      }));
    }
  };

  const [paymentConfig, setPaymentConfig] = useState({
    showDialog: false,
    transactionId: '',
    isVerifying: false
  });

  useEffect(() => {
    const handleScroll = () => {
      const isScrolled = window.scrollY > 50;
      setScrolled(prev => {
        if (prev !== isScrolled) return isScrolled;
        return prev;
      });
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleVerifyCoursePayment = () => {
    if (!coursePaymentConfig.transactionId) return;
    setCoursePaymentConfig(prev => ({ ...prev, isVerifying: true }));
    setTimeout(() => {
      setCoursePaymentConfig(prev => ({ ...prev, isVerifying: false, verified: true }));
    }, 1500);
  };

  const handleCopyUPI = () => {
    navigator.clipboard.writeText('9996409052@upi');
    setCoursePaymentConfig(prev => ({ ...prev, copied: true }));
    setTimeout(() => {
      setCoursePaymentConfig(prev => ({ ...prev, copied: false }));
    }, 2000);
  };

  const handlePhotoChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setStudentData(prev => ({ ...prev, photo: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDownload = () => {
    if (!studentData.isPaid) {
      setPaymentConfig(prev => ({ ...prev, showDialog: true }));
      return;
    }
    window.print();
  };

  const handleDownloadPDF = async () => {
    if (!studentData.isPaid) {
      setPaymentConfig(prev => ({ ...prev, showDialog: true }));
      return;
    }

    if (cardRef.current) {
      try {
        setIsDownloading(true);
        // Small delay to ensure any pending state updates are reflected
        await new Promise(resolve => setTimeout(resolve, 100));

        const canvas = await html2canvas(cardRef.current, {
          scale: 3, // Increased scale for higher quality
          useCORS: true,
          backgroundColor: '#ffffff',
          logging: false,
          onclone: (clonedDoc) => {
            // Find the card in the cloned document and reset transforms for a flat capture
            const clonedCard = clonedDoc.querySelector('[data-card-capture="true"]');
            if (clonedCard instanceof HTMLElement) {
              clonedCard.style.transform = 'none';
              clonedCard.style.perspective = 'none';
              // Ensure the motion animation is stopped in the clone
              clonedCard.style.animation = 'none';
              clonedCard.style.transition = 'none';
            }
          }
        });

        const imgData = canvas.toDataURL('image/png', 1.0);
        const pdf = new jsPDF({
          orientation: 'portrait',
          unit: 'px',
          format: [canvas.width / 3, canvas.height / 3]
        });

        pdf.addImage(imgData, 'PNG', 0, 0, canvas.width / 3, canvas.height / 3);
        pdf.save(`AmericanInstitute_ID_${studentData.name.replace(/\s+/g, '_') || 'Student'}.pdf`);
      } catch (error) {
        console.error('PDF Generation failed:', error);
        alert('Failed to generate PDF. Please try again.');
      } finally {
        setIsDownloading(false);
      }
    }
  };

  const handleVerifyPayment = async () => {
    if (!paymentConfig.transactionId || !currentUser) return;
    
    setPaymentConfig(prev => ({ ...prev, isVerifying: true }));
    
    // Simulate verification
    setTimeout(async () => {
      const generatedId = `AI-${Math.random().toString(36).substring(2, 6).toUpperCase()}-${new Date().getFullYear()}`;
      
      const updatedData = { 
        ...studentData, 
        uid: currentUser.uid,
        isPaid: true,
        uniqueId: generatedId,
        updatedAt: serverTimestamp()
      };

      try {
        await setDoc(doc(db, 'students', currentUser.uid), updatedData, { merge: true });
        setStudentData(updatedData as any);
        setPaymentConfig(prev => ({ ...prev, isVerifying: false, showDialog: false }));
        
        // Trigger Email delivery (Call Backend)
        if (cardRef.current) {
          const canvas = await html2canvas(cardRef.current, { scale: 1, logging: false });
          const cardImage = canvas.toDataURL('image/png');
          
          fetch('/api/email-card', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              email: currentUser.email,
              studentName: updatedData.name,
              uniqueId: generatedId,
              cardImage: cardImage
            })
          })
          .then((res) => {
            if (!res.ok) {
              console.warn("Backend email dispatch returned " + res.status + " (expected in static client hosts like Netlify Drop where backend does not run).");
            } else {
              console.log("Email dispatch successfully scheduled.");
            }
          })
          .catch((err) => {
            console.warn("Backend email dispatch request failed (expected on a static host):", err);
          });
        }

      } catch (error) {
        console.error("Failed to save data:", error);
        alert("Failed to save record. Payment was simulated but data sync failed.");
      }
    }, 1500);
  };

  const navLinks = [
    { name: 'About', href: '#about' },
    { name: 'Courses', href: '#courses' },
    { name: 'Why Us', href: '#why-us' },
    { name: 'E-Card', href: '#ecard' },
    { name: 'Contact', href: '#contact' },
  ];

  const courses = [
    {
      title: "Spoken English",
      description: "Master the art of conversation. We focus on pronunciation, vocabulary, and removing stage fear to build real-world confidence.",
      icon: <Users className="w-8 h-8 text-blue-600" />,
      color: "blue"
    },
    {
      title: "IELTS",
      description: "Comprehensive preparation for Academic and General Training modules. Focused training to achieve Band 7+ scores.",
      icon: <GraduationCap className="w-8 h-8 text-rose-600" />,
      color: "rose"
    },
    {
      title: "PTE",
      description: "Fast-track your dreams with our specialized PTE coaching. Score optimally in Writing, Speaking, Reading, and Listening.",
      icon: <Globe className="w-8 h-8 text-amber-600" />,
      color: "amber"
    },
    {
      title: "OET",
      description: "Tailored English training specifically for healthcare professionals looking to work in an English-speaking environment.",
      icon: <CheckCircle2 className="w-8 h-8 text-emerald-600" />,
      color: "emerald"
    }
  ];

  const features = [
    "Group Discussions",
    "Interactive Games",
    "Weekly Presentations",
    "Offline/Online Classes",
    "1-on-1 Personalized Coaching",
    "Stage Fear Removal"
  ];

  return (
    <div className="min-h-screen bg-slate-50/50 cinematic-grid font-sans text-slate-900 selection:bg-blue-100 italic-selection overflow-x-hidden">
      {/* Cinematic Scroll Progress Line */}
      <motion.div 
        className="fixed top-0 left-0 right-0 h-[4px] bg-gradient-to-r from-blue-500 via-indigo-500 to-cyan-400 z-50 origin-left"
        style={{ scaleX }}
      />
      
      {/* WhatsApp FAB */}
      <motion.a
        href="https://wa.me/919996409052" // Institution WhatsApp
        target="_blank"
        rel="noopener noreferrer"
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        whileHover={{ scale: 1.1 }}
        className="fixed bottom-8 right-8 z-50 bg-[#25D366] text-white p-4 rounded-full shadow-2xl flex items-center justify-center cursor-pointer"
        id="whatsapp-fab"
      >
        <MessageCircle fill="currentColor" className="w-8 h-8" />
        <span className="sr-only">Contact on WhatsApp</span>
      </motion.a>

      {/* Navigation */}
      <nav 
        className={`fixed top-0 w-full z-40 transition-all duration-300 ${
          scrolled ? 'glass-nav py-3' : 'bg-transparent py-5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
          <div className="flex items-center">
            <img 
              src="https://www.image2url.com/r2/default/images/1779184710333-1ee81e53-2043-45ef-adb8-76c7977cacaf.png" 
              alt="American Institute of English" 
              className="h-10 w-auto object-contain"
              referrerPolicy="no-referrer"
            />
          </div>

          {/* Desktop Nav */}
          <div className="hidden md:flex gap-8 items-center">
            {navLinks.map((link) => (
              <a 
                key={link.name} 
                href={link.href}
                className={`text-sm font-semibold tracking-wide hover:text-blue-500 transition-colors ${
                  scrolled ? 'text-slate-700' : 'text-slate-100'
                }`}
              >
                {link.name}
              </a>
            ))}
            
            {currentUser ? (
              <div className="flex items-center gap-4 border-l border-white/20 pl-6 h-8">
                <div className="flex flex-col items-end">
                  <span className={`text-[10px] font-bold uppercase tracking-tight ${scrolled ? 'text-slate-400' : 'text-white/60'}`}>Logged in as</span>
                  <span className={`text-xs font-extrabold ${scrolled ? 'text-blue-900' : 'text-white'}`}>{currentUser.displayName}</span>
                </div>
                <button 
                  onClick={handleSignOut}
                  className={`text-xs font-bold px-3 py-1.5 rounded-lg border transition-all ${
                    scrolled ? 'border-slate-200 text-slate-600 hover:bg-slate-100' : 'border-white/20 text-white hover:bg-white/10'
                  }`}
                >
                  Logout
                </button>
              </div>
            ) : (
              <button 
                onClick={handleSignIn}
                className={`flex items-center gap-2 px-5 py-2.5 rounded-full font-bold transition-all ${
                  scrolled 
                    ? 'bg-blue-900 text-white hover:bg-blue-800' 
                    : 'bg-white text-blue-900 hover:bg-slate-100'
                }`}
              >
                Sign In
              </button>
            )}
          </div>

          {/* Mobile Menu Toggle */}
          <button 
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? (
              <X className={scrolled ? 'text-slate-900' : 'text-white'} />
            ) : (
              <Menu className={scrolled ? 'text-slate-900' : 'text-white'} />
            )}
          </button>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="absolute top-full left-0 w-full bg-white shadow-xl md:hidden border-t"
            >
              <div className="px-6 py-8 flex flex-col gap-6">
                {navLinks.map((link) => (
                  <a 
                    key={link.name} 
                    href={link.href}
                    onClick={() => setIsMenuOpen(false)}
                    className="text-lg font-bold text-slate-800 hover:text-blue-600 transition-colors"
                  >
                    {link.name}
                  </a>
                ))}
                <a 
                  href="#contact" 
                  onClick={() => setIsMenuOpen(false)}
                  className="bg-blue-900 text-white py-4 rounded-xl text-center font-bold"
                >
                  Join Today
                </a>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center pt-20 hero-gradient overflow-hidden">
        {/* Animated Background Elements */}
        <div className="absolute inset-0 z-0">
          {[...Array(6)].map((_, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0 }}
              animate={{ 
                opacity: [0.05, 0.1, 0.05],
                scale: [1, 1.2, 1],
                x: [0, 50, 0],
                y: [0, 50, 0]
              }}
              transition={{ 
                duration: 10 + i * 2, 
                repeat: Infinity,
                ease: "easeInOut" 
              }}
              className="absolute bg-blue-400/20 rounded-full blur-3xl"
              style={{
                width: `${200 + i * 100}px`,
                height: `${200 + i * 100}px`,
                left: `${(i * 20) % 100}%`,
                top: `${(i * 15) % 100}%`,
              }}
            />
          ))}
        </div>

        <div className="relative z-10 max-w-4xl mx-auto px-6 text-center">
          <div className="flex flex-col items-center">
            <motion.span 
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
              className="inline-block py-1.5 px-5 rounded-full bg-blue-500/10 text-blue-300 text-xs font-bold uppercase tracking-widest mb-6 border border-blue-500/20 backdrop-blur-sm"
            >
              Welcome to Rohtak's Premier English Hub
            </motion.span>
            
            <motion.h1 
              initial={{ opacity: 0, scale: 0.95, y: 25 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              transition={{ duration: 1, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
              className="font-display text-5xl md:text-7xl font-extrabold text-white leading-[0.9] tracking-tighter mb-8"
            >
              MASTER ENGLISH <br/>
              <span className="text-blue-400 bg-linear-to-r from-blue-400 to-indigo-300 bg-clip-text text-transparent">CONQUER THE WORLD.</span>
            </motion.h1>
            
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
              className="text-xl text-slate-300 mb-10 max-w-2xl leading-relaxed font-medium"
            >
              Join American Institute to eliminate stage fear and skyrocket your career with confident Spoken English, IELTS, PTE, and OET skills.
            </motion.p>
            
            <motion.div 
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.3, ease: [0.16, 1, 0.3, 1] }}
              className="flex flex-col sm:flex-row gap-4 justify-center"
            >
              <a 
                href="#contact"
                className="group relative px-8 py-4 bg-white text-blue-900 rounded-xl font-extrabold text-lg transition-all hover:scale-105 hover:shadow-blue-500/10 hover:shadow-2xl active:scale-95 flex items-center justify-center gap-2 overflow-hidden border border-white"
              >
                Join Now <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </a>
              <a 
                href="#courses"
                className="px-8 py-4 bg-white/5 border-2 border-white/20 hover:border-white/50 hover:bg-white/10 text-white rounded-xl font-bold text-lg transition-all backdrop-blur-sm flex items-center justify-center"
              >
                Explore Courses
              </a>
            </motion.div>
          </div>

          <motion.div 
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.2 }}
            className="hidden"
          >
            <div className="relative w-full aspect-square bg-blue-800/30 rounded-3xl overflow-hidden border border-white/10 shadow-2xl">
              <img 
                src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxISEhUSEhAVFhUVFRUVFRUVFRUVFRUVFRUWFhUVFRUYHSggGBolGxUVITEhJSorLi4uFx8zODMtNygtLi0BCgoKDg0OGxAQGi0lHSYrLS0tLS0tLS0tKy0vLS0rKy0tKy0tLS0tLS0tLS0rKy0tLS0tLS0tLS0tLS0tKy0tLf/AABEIAMgA/AMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAABAAIDBAUGBwj/xABDEAACAQICBQgGCAUDBQEAAAABAgADEQQhBRIxQVEGEyJhcYGRoTJSkrHB0QcUFRYjQlNUYoKTouEzQ3KjssLw8UT/xAAZAQEAAwEBAAAAAAAAAAAAAAAAAQIDBAX/xAAoEQACAgICAgIBBAMBAAAAAAAAAQIRAyESMQRBE1FhFCKBkRUysQX/2gAMAwEAAhEDEQA/AL9orQRXlDjCRFaK8AMAIEFoRAYArQRwgMAVoDCITAGwR4EFoAy0UJigDSIrSrV0jTVrEnYTsNstvS2Sm+mwSAq2vaxYgAg7wL5yrkjSOGcvRqEQ2mY2mkVtV1PUVsVtx4zRpYlGNldSeAIJ8ITIljlHtDtWK0fBaSUIzGiSlYQskEYWPURwEIEEgEfBaEQAasMUUAURigEAIihggBIiAgaIGCA2gtETBAHWitBeCAPgtHUkZjZQSeAzlsaHxBz5o+K/OBRTEUfWw7pk6kX2X39hkRMARijCYtaAOcTM0tiyo1V2kXBELmMus/Ay+TOG0w71G5xb9I3G/K4RbeXiOErJm/jw5St+g4ham0k3vtPog7QAd52dfxWCoo59K772Ykm/Esdn+JJoqhUqsKNnd2OqFBJuxJy25gZ7bDIzq6nIJqFMtVqdNwbgbADkRfed0z5JdnoKDZwVWqNa2trDqFweoE7Rtk+FbeHIZc1NtueydNW5LK1Kgymwdgg49C5y4394jRyfCEhjbet/d3G3nJc0R8bRb0XjyygVNtr6w2EcSNozPdvtNO05bFV+bP4ZBKubAjIgkgoe0EduO0w71G5xb9I3G/K4RbeXiOErJm/jw5St+g4ham0k3vtPog7QAd52dfxWCoo59K772Ykm/Esdn+JJoqhUqsKNnd2OqFBJuxJy25gZ7bDIzq6nIJqFMtVqdNwbgbADkRfed0z5JdnoKDZwVWqNa2trDqFweoE7Rtk+FbeHIZc1NtueydNW5LK1Kgymwdgg49C5y4394jRyfCEhjbet/d3G3nJc0R8bRb0XjyygVNtr6w2EcSNozPdvtNO05bFV+bP4ZBKubAjIgkgoe0EduO0w71G5xb9I3G/K4RbeXiOErJm/jw5St+g4ham0k3vtPog7QAd52dfxWCoo59K772Ykm/Esdn+JJoqhUqsKNnd2OqFBJuxJy25gZ7bDIzq6nIJqFMtVqdNwbgbADkRfed0z5JdnoKDZwVWqNa2trDqFweoE7Rtk+FbeHIZc1NtueydNW5LK1Kgymwdgg49C5y4394jRyfCEhjbet/d3G3nJc0R8bRb0XjyygVNtr6w2EcSNozPdvtNO05bFV+bP4ZBKubAjIgkgoe0Edu" 
                alt="Confident Student" 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-blue-900/80 via-transparent to-transparent" />
              
              <div className="absolute bottom-8 left-8 right-8 bg-white/10 backdrop-blur-md border border-white/10 rounded-2xl p-6">
                <div className="flex items-center gap-4 mb-3">
                  <div className="flex -space-x-2">
                    {[...Array(4)].map((_, i) => (
                      <div key={i} className="w-8 h-8 rounded-full border-2 border-slate-900 bg-blue-500" />
                    ))}
                  </div>
                  <span className="text-white text-sm font-bold">500+ Students Transformed</span>
                </div>
                <p className="text-white/80 text-xs italic font-medium leading-relaxed">
                  "The American Institute changed my life. I went from being scared of speaking to leading presentations at my MNC."
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-24 bg-slate-50">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, x: -30 }}
              whileInView={{ opacity: 1, scale: 1, x: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
              className="relative group"
            >
              <div className="relative z-10 rounded-3xl overflow-hidden shadow-2xl bg-white border border-slate-100">
                <img 
                  src="https://www.image2url.com/r2/default/images/1779183773659-8441d91c-9c3e-4cf8-aa2e-c61ed79dcf1d.png" 
                  alt="Director Manpal Kinha" 
                  className="w-full h-auto block transform transition-transform duration-700 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                />
              </div>
              {/* Floating Cinematic Blob */}
              <motion.div 
                animate={{ y: [0, -12, 0], scale: [1, 1.06, 1] }}
                transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
                className="absolute -bottom-6 -right-6 w-32 h-32 bg-linear-to-tr from-blue-600 to-indigo-500 rounded-full z-0 shadow-xl opacity-60 filter blur-xs"
              />
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 40 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ duration: 1, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
            >
              <div className="mb-6 flex items-center gap-2">
                <div className="w-12 h-[2px] bg-blue-600" />
                <span className="text-blue-600 font-bold uppercase tracking-widest text-sm">About Our Institute</span>
              </div>
              <h2 className="text-4xl md:text-5xl font-extrabold font-display leading-tight mb-8">
                Building Real Confidence, <br />
                One Student At A Time.
              </h2>
              <p className="text-lg text-slate-600 mb-6 leading-relaxed">
                Led by <span className="font-bold text-blue-900">Director Manpal Kinha</span>, the American Institute is more than just an English center. We are a transformational hub located in the heart of Rohtak.
              </p>
              <p className="text-lg text-slate-600 mb-8 leading-relaxed italic border-l-4 border-blue-600 pl-6 bg-white py-4 rounded-r-xl shadow-sm">
                "Our mission is to remove stage fear and empower every student with the language skills they need to compete on a global stage."
              </p>
              
              <div className="grid grid-cols-2 gap-6">
                <div className="p-4 bg-white rounded-2xl shadow-sm border border-slate-100">
                  <h4 className="text-2xl font-bold text-blue-900 mb-1">10+</h4>
                  <p className="text-sm font-semibold text-slate-500">Years Excellence</p>
                </div>
                <div className="p-4 bg-white rounded-2xl shadow-sm border border-slate-100">
                  <h4 className="text-2xl font-bold text-blue-900 mb-1">98%</h4>
                  <p className="text-sm font-semibold text-slate-500">Success Rate</p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Courses Section */}
      <section id="courses" className="py-24">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-4xl font-display font-extrabold mb-4">Specialized Courses</h2>
            <p className="text-lg text-slate-500">Designed to meet international standards and your specific career goals.</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {courses.map((course, i) => (
              <motion.div
                key={course.title}
                initial={{ opacity: 0, y: 40, scale: 0.95 }}
                whileInView={{ opacity: 1, y: 0, scale: 1 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ 
                  duration: 0.8, 
                  delay: i * 0.1, 
                  type: "spring", 
                  stiffness: 110, 
                  damping: 15 
                }}
                whileHover={{ 
                  y: -12, 
                  scale: 1.03,
                  boxShadow: "0 25px 60px -15px rgba(59, 130, 246, 0.15)",
                }}
                onClick={() => setCoursePaymentConfig({
                  showDialog: true,
                  selectedCourse: course,
                  amount: '1500',
                  transactionId: '',
                  isVerifying: false,
                  verified: false,
                  copied: false
                })}
                className="group p-8 bg-white rounded-3xl border border-slate-100 shadow-md course-card hover:border-blue-300 cursor-pointer relative overflow-hidden flex flex-col justify-between"
              >
                <div>
                  <motion.div 
                    whileHover={{ rotate: 12, scale: 1.15 }}
                    transition={{ type: "spring", stiffness: 300, damping: 12 }}
                    className={`w-16 h-16 rounded-2xl flex items-center justify-center mb-6 bg-${course.color}-50`}
                  >
                    {course.icon}
                  </motion.div>
                  <h3 className="text-xl font-bold mb-4">{course.title}</h3>
                  <p className="text-slate-500 text-sm leading-relaxed mb-6">
                    {course.description}
                  </p>
                </div>
                <div className="flex items-center justify-between mt-auto pt-4 border-t border-slate-50">
                  <span className="text-blue-600 font-bold text-sm flex items-center gap-1 group-hover:gap-2 transition-all">
                    Enroll Now <ChevronRight className="w-4 h-4" />
                  </span>
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest bg-slate-50 py-1 px-2.5 rounded-full">
                    UPI Active
                  </span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section id="why-us" className="py-24 bg-blue-900 text-white relative overflow-hidden">
        <div className="absolute top-0 right-0 w-1/3 h-full bg-blue-800 skew-x-animation opacity-20" />
        
        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-4xl md:text-5xl font-display font-extrabold mb-8 tracking-tight">
                Why American Institute <br /> Stands Out?
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-y-6 gap-x-12">
                {features.map((feature, i) => (
                  <motion.div 
                    key={feature}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.1 }}
                    className="flex items-center gap-3"
                  >
                    <div className="w-6 h-6 rounded-full bg-blue-500 flex items-center justify-center flex-shrink-0">
                      <CheckCircle2 className="w-4 h-4 text-white" />
                    </div>
                    <span className="font-semibold text-slate-200">{feature}</span>
                  </motion.div>
                ))}
              </div>
              
              <div className="mt-12 p-8 bg-white/5 backdrop-blur-sm rounded-3xl border border-white/10">
                <div className="flex gap-6 mb-6">
                  <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-blue-500 flex items-center justify-center">
                    <Clock className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-bold text-xl mb-1">Open 12 Hours Daily</h4>
                    <p className="text-slate-400 text-sm">Flexible batches starting from morning to late evening.</p>
                  </div>
                </div>
                <div className="flex gap-6">
                  <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-blue-500 flex items-center justify-center">
                    <Zap className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-bold text-xl mb-1">Weekly Mock Tests</h4>
                    <p className="text-slate-400 text-sm">Real-time examination environment for IELTS and PTE.</p>
                  </div>
                </div>
              </div>
            </div>

            <motion.div 
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-100px" }}
              variants={{
                hidden: { opacity: 0 },
                visible: {
                  opacity: 1,
                  transition: { staggerChildren: 0.15 }
                }
              }}
              className="grid grid-cols-2 gap-4"
            >
              <div className="space-y-4">
                <motion.div 
                  variants={{
                    hidden: { opacity: 0, y: 35 },
                    visible: { opacity: 1, y: 0, transition: { type: "spring", stiffness: 100, damping: 15 } }
                  }}
                  whileHover={{ scale: 1.04 }}
                  className="h-64 rounded-3xl overflow-hidden shadow-2xl group cursor-pointer"
                >
                  <img src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&q=80&w=800" alt="Students collab" className="w-full h-full object-cover transform transition-transform duration-700 group-hover:scale-110" referrerPolicy="no-referrer" />
                </motion.div>
                <motion.div 
                  variants={{
                    hidden: { opacity: 0, y: 35 },
                    visible: { opacity: 1, y: 0, transition: { type: "spring", stiffness: 100, damping: 15 } }
                  }}
                  whileHover={{ y: -6, scale: 1.03 }}
                  className="h-48 rounded-3xl bg-blue-600 flex flex-col justify-center items-center p-6 text-center shadow-2xl"
                >
                  <Award className="w-10 h-10 mb-2 opacity-50 text-white animate-pulse" />
                  <p className="font-extrabold text-2xl text-white">Certified</p>
                  <p className="text-xs uppercase tracking-widest text-blue-200">Excellence</p>
                </motion.div>
              </div>
              <div className="space-y-4 pt-8">
                <motion.div 
                  variants={{
                    hidden: { opacity: 0, y: 35 },
                    visible: { opacity: 1, y: 0, transition: { type: "spring", stiffness: 100, damping: 15 } }
                  }}
                  whileHover={{ y: -6, scale: 1.03 }}
                  className="h-48 rounded-3xl bg-white text-blue-900 p-8 flex flex-col justify-end shadow-2xl relative"
                >
                  <Star className="absolute top-6 right-6 w-8 h-8 text-amber-400 fill-amber-400 animate-pulse" />
                  <p className="text-3xl font-extrabold leading-none italic">#1</p>
                  <p className="text-xs font-bold uppercase tracking-wide">Rated in Rohtak</p>
                </motion.div>
                <motion.div 
                  variants={{
                    hidden: { opacity: 0, y: 35 },
                    visible: { opacity: 1, y: 0, transition: { type: "spring", stiffness: 100, damping: 15 } }
                  }}
                  whileHover={{ scale: 1.04 }}
                  className="h-64 rounded-3xl overflow-hidden shadow-2xl group cursor-pointer"
                >
                  <img src="https://images.unsplash.com/photo-1524178232363-1fb28f74b55a?auto=format&fit=crop&q=80&w=800" alt="Teaching" className="w-full h-full object-cover transform transition-transform duration-700 group-hover:scale-110" referrerPolicy="no-referrer" />
                </motion.div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* E-Card Section */}
      <section id="ecard" className="py-24 bg-slate-50 overflow-hidden">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-4xl font-display font-extrabold mb-4">Generate Your E-Card</h2>
            <p className="text-lg text-slate-500">Create your official digital student ID card in seconds. Fill in your details below.</p>
          </div>

          <div className="grid lg:grid-cols-2 gap-16 items-start">
            {/* Form Column */}
            <motion.div 
              initial={{ opacity: 0, x: -50, scale: 0.98 }}
              whileInView={{ opacity: 1, x: 0, scale: 1 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.8, type: "spring", stiffness: 85, damping: 14 }}
              className="bg-white p-8 md:p-10 rounded-[2rem] shadow-xl border border-slate-100"
            >
              <h3 className="text-2xl font-bold mb-8 flex items-center gap-3">
                <span className="w-8 h-8 rounded-lg bg-blue-600 text-white flex items-center justify-center text-sm">1</span>
                Student Details
              </h3>
              <div className="space-y-6">
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest text-slate-400 ml-1">Full Name</label>
                  <input 
                    type="text" 
                    placeholder="Enter your name" 
                    value={studentData.name}
                    onChange={(e) => setStudentData(prev => ({ ...prev, name: e.target.value }))}
                    className="w-full px-6 py-4 rounded-2xl bg-slate-50 border-transparent focus:border-blue-500 focus:bg-white focus:ring-0 transition-all font-semibold outline-hidden"
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-widest text-slate-400 ml-1">ID Type</label>
                    <select 
                      value={studentData.idType}
                      onChange={(e) => {
                        const newType = e.target.value as 'Aadhaar' | 'PAN';
                        setStudentData(prev => ({ ...prev, idType: newType, idNumber: '' }));
                        setErrors(prev => ({ ...prev, idNumber: '' }));
                      }}
                      className="w-full px-6 py-4 rounded-2xl bg-slate-50 border-transparent focus:border-blue-500 focus:bg-white focus:ring-0 transition-all font-semibold outline-hidden"
                    >
                      <option value="Aadhaar">Aadhaar Card</option>
                      <option value="PAN">PAN Card</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-widest text-slate-400 ml-1">{studentData.idType} Number</label>
                    <input 
                      type="text" 
                      placeholder={studentData.idType === 'Aadhaar' ? "1234 5678 9012" : "ABCDE1234F"}
                      value={studentData.idNumber}
                      onChange={(e) => handleIdNumberChange(e.target.value)}
                      className={`w-full px-6 py-4 rounded-2xl bg-slate-50 border-2 transition-all font-semibold outline-hidden ${
                        errors.idNumber ? 'border-rose-400 focus:border-rose-500' : 'border-transparent focus:border-blue-500'
                      }`}
                    />
                    {errors.idNumber && (
                      <p className="text-[10px] text-rose-500 font-bold ml-1">{errors.idNumber}</p>
                    )}
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest text-slate-400 ml-1">Select Course</label>
                  <select 
                    value={studentData.course}
                    onChange={(e) => setStudentData(prev => ({ ...prev, course: e.target.value }))}
                    className="w-full px-6 py-4 rounded-2xl bg-slate-50 border-transparent focus:border-blue-500 focus:bg-white focus:ring-0 transition-all font-semibold appearance-none outline-hidden"
                  >
                    <option>Spoken English</option>
                    <option>IELTS</option>
                    <option>PTE</option>
                    <option>OET</option>
                  </select>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest text-slate-400 ml-1">Profile Photo</label>
                  <div className="relative">
                    <input 
                      type="file" 
                      accept="image/*"
                      onChange={handlePhotoChange}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                    />
                    <div className="w-full px-6 py-10 rounded-2xl bg-slate-50 border-2 border-dashed border-slate-200 flex flex-col items-center justify-center gap-3 transition-colors hover:border-blue-400">
                      <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center text-blue-600">
                        <Users className="w-6 h-6" />
                      </div>
                      <p className="text-sm font-bold text-slate-500">Click or Drag to Upload Photo</p>
                      <span className="text-xs text-slate-400">PNG, JPG up to 5MB</span>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Card Column */}
            <motion.div 
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="flex justify-center lg:sticky lg:top-32"
            >
              <div className="w-full max-w-[380px] perspective mt-10 lg:mt-0 relative">
                {/* Lock Overlay */}
                <AnimatePresence>
                  {!studentData.isPaid && (
                    <motion.div 
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="absolute inset-0 z-20 backdrop-blur-md bg-white/40 rounded-[2rem] flex flex-col items-center justify-center p-8 text-center border-2 border-dashed border-blue-200"
                    >
                      <div className="w-16 h-16 rounded-full bg-blue-600 text-white flex items-center justify-center mb-4 shadow-xl">
                        <Star className="w-8 h-8" />
                      </div>
                      <h4 className="text-xl font-display font-extrabold text-blue-900 mb-2">Card Locked</h4>
                      <p className="text-sm text-slate-600 mb-6">
                        {currentUser 
                          ? "Complete the registration payment to generate and view your official ID card." 
                          : "Please Sign In to start your E-Card registration and unlock this card."}
                      </p>
                      {currentUser ? (
                        <button 
                          onClick={() => setPaymentConfig(prev => ({ ...prev, showDialog: true }))}
                          disabled={!!errors.idNumber || !studentData.idNumber || !studentData.name}
                          className="px-6 py-3 bg-blue-900 text-white rounded-xl font-bold text-sm shadow-lg hover:bg-blue-800 transition-all disabled:opacity-50"
                        >
                          Unlock Now (₹199)
                        </button>
                      ) : (
                        <button 
                          onClick={handleSignIn}
                          className="px-6 py-3 bg-blue-900 text-white rounded-xl font-bold text-sm shadow-lg hover:bg-blue-800 transition-all"
                        >
                          Sign In to Unlock
                        </button>
                      )}
                    </motion.div>
                  )}
                </AnimatePresence>

                <motion.div 
                  ref={cardRef}
                  data-card-capture="true"
                  className={`relative w-full aspect-[2/3] bg-white rounded-[2rem] shadow-[0_20px_50px_rgba(0,0,0,0.15)] overflow-hidden border border-slate-100 print:shadow-none print:border-none duration-500 ${!studentData.isPaid ? 'opacity-20 grayscale' : ''}`}
                  animate={studentData.isPaid ? { 
                    rotateY: [-4, 4, -4], 
                    rotateX: [-2, 2, -2], 
                    y: [0, -8, 0] 
                  } : {}}
                  transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
                  whileHover={studentData.isPaid ? { scale: 1.04, rotateY: 8, rotateX: 4, y: -12 } : {}}
                >
                  {/* Card Header */}
                  <div className="h-[35%] bg-blue-900 relative p-8 flex flex-col justify-between items-center text-center">
                    <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
                      <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_center,_white_1px,_transparent_1px)] [background-size:20px_20px]" />
                    </div>
                    <div className="font-display font-extrabold text-white text-lg tracking-tighter leading-none">
                      AMERICAN <br/>
                      <span className="text-blue-400">INSTITUTE</span>
                    </div>
                    <div className="text-[10px] uppercase tracking-widest text-blue-300 font-bold">Official Student ID</div>
                    
                    {/* Circle cutouts for design */}
                    <div className="absolute -bottom-10 left-1/2 -translate-x-1/2 w-28 h-28 bg-white rounded-full border-[8px] border-white shadow-lg overflow-hidden flex items-center justify-center bg-slate-100">
                      {studentData.photo ? (
                        <img src={studentData.photo} alt="Student" className="w-full h-full object-cover" />
                      ) : (
                        <Users className="w-12 h-12 text-blue-200" />
                      )}
                    </div>
                  </div>

                  {/* Card Body */}
                  <div className="pt-20 pb-10 px-8 text-center flex flex-col items-center">
                    <div className="mb-8">
                      <h4 className="text-2xl font-display font-extrabold text-slate-900 mb-1 truncate max-w-[280px]">
                        {studentData.name || "STUDENT NAME"}
                      </h4>
                      <p className="text-blue-600 text-xs font-bold uppercase tracking-widest">
                        {studentData.course} Student
                      </p>
                    </div>

                    <div className="w-full space-y-4 mb-8">
                      <div className="flex justify-between items-center border-b border-slate-100 pb-2">
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Student ID</span>
                        <span className="font-mono text-sm font-bold text-slate-700">{studentData.uniqueId || "AI-XXXX-2024"}</span>
                      </div>
                      <div className="flex justify-between items-center border-b border-slate-100 pb-2">
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">{studentData.idType} No.</span>
                        <span className="font-mono text-sm font-bold text-slate-700">
                          {studentData.idNumber ? `**** **** ${studentData.idNumber.slice(-4)}` : "REQUIRED"}
                        </span>
                      </div>
                      <div className="flex justify-between items-center border-b border-slate-100 pb-2">
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Status</span>
                        <span className="inline-flex items-center gap-1.5 py-0.5 px-2 rounded-full bg-emerald-100 text-emerald-700 text-[10px] font-bold">
                          <span className="w-1 h-1 rounded-full bg-emerald-500 animate-pulse" />
                          ACTIVE
                        </span>
                      </div>
                    </div>

                    {/* QR Code Placeholder */}
                    <div className="w-16 h-16 bg-slate-50 border border-slate-100 p-2 rounded-lg opacity-40">
                      <div className="w-full h-full grid grid-cols-4 grid-rows-4 gap-1">
                        {[...Array(16)].map((_, i) => (
                          <div key={i} className={`rounded-[1px] ${Math.random() > 0.5 ? 'bg-slate-900' : 'bg-transparent'}`} />
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Card Footer */}
                  <div className="absolute bottom-0 left-0 w-full bg-slate-50 py-3 px-8 text-center border-t border-slate-100">
                    <p className="text-[10px] text-slate-400 font-medium">Jhajjar Road, Rohtak | americaninstitute.in</p>
                  </div>
                </motion.div>
                
                {/* Download Button */}
                <div className="relative group/btn">
                  {!studentData.isPaid && (
                    <div className="absolute -top-12 left-1/2 -translate-x-1/2 bg-blue-600 text-white text-[10px] font-bold py-1 px-3 rounded-full opacity-0 group-hover/btn:opacity-100 transition-opacity whitespace-nowrap shadow-lg">
                      Payment of ₹199 Required
                    </div>
                  )}
                  <button 
                    onClick={handleDownload}
                    disabled={!!errors.idNumber || !studentData.idNumber || !studentData.name}
                    className={`mt-8 w-full py-4 rounded-2xl font-bold transition-all flex items-center justify-center gap-2 border-2 ${
                      studentData.isPaid 
                        ? 'bg-emerald-50 text-emerald-600 border-emerald-100 hover:bg-emerald-100' 
                        : (!!errors.idNumber || !studentData.idNumber || !studentData.name)
                          ? 'bg-slate-50 text-slate-300 border-slate-100 cursor-not-allowed'
                          : 'bg-white text-slate-600 border-slate-100 hover:text-blue-600 hover:border-blue-100'
                    }`}
                  >
                    {studentData.isPaid ? (
                      <><CheckCircle2 className="w-5 h-5" /> Print E-Card</>
                    ) : (
                      <><Award className="w-5 h-5" /> Pay & Unlock Card</>
                    )}
                  </button>

                  {studentData.isPaid && (
                    <button 
                      onClick={handleDownloadPDF}
                      disabled={isDownloading}
                      className="mt-4 w-full py-4 bg-blue-600 text-white rounded-2xl font-bold transition-all flex items-center justify-center gap-2 hover:bg-blue-700 shadow-lg shadow-blue-200 disabled:opacity-70"
                    >
                      {isDownloading ? (
                        <>
                          <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                          Processing...
                        </>
                      ) : (
                        <>
                          <Download className="w-5 h-5" /> Download PDF
                        </>
                      )}
                    </button>
                  )}
                </div>
              </div>
            </motion.div>
          </div>
        </div>

        {/* Payment Dialog */}
        <AnimatePresence>
          {paymentConfig.showDialog && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-6">
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setPaymentConfig(prev => ({ ...prev, showDialog: false }))}
                className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
              />
              <motion.div 
                initial={{ opacity: 0, scale: 0.9, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: 20 }}
                className="relative w-full max-w-md bg-white rounded-[2.5rem] shadow-2xl overflow-hidden"
              >
                <div className="p-8 md:p-10 text-center">
                  <div className="w-20 h-20 rounded-full bg-blue-50 flex items-center justify-center text-blue-600 mx-auto mb-6">
                    <Zap className="w-10 h-10" />
                  </div>
                  <h3 className="text-2xl font-display font-extrabold text-slate-900 mb-2">Unlock Your E-Card</h3>
                  <p className="text-slate-500 mb-8 text-sm">To generate your official digital ID, please complete the payment of <span className="font-bold text-blue-600">₹199</span>.</p>
                  
                  <div className="bg-slate-50 rounded-3xl p-6 mb-8 text-left border border-slate-100">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-3">Payment Options</p>
                    <div className="space-y-4">
                      {/* UPI Deep Link Button for Mobile */}
                      <a 
                        href={`upi://pay?pa=9996409052@upi&pn=American%20Institute&am=199&cu=INR&tn=ID%20Card%20Registration`}
                        className="flex items-center justify-center gap-3 w-full py-4 bg-white border-2 border-blue-100 rounded-2xl text-blue-900 font-extrabold hover:bg-blue-50 transition-all shadow-sm md:hidden"
                      >
                        <Zap className="w-5 h-5 fill-blue-600 text-blue-600" />
                        Pay via UPI App
                      </a>

                      <div className="hidden md:block text-center py-2 px-4 bg-blue-50 rounded-xl border border-blue-100 mb-4">
                        <p className="text-[10px] font-bold text-blue-800 uppercase tracking-wide">Desktop User?</p>
                        <p className="text-xs text-blue-900/60 font-medium leading-tight">Scan with your mobile to pay or enter details below</p>
                      </div>

                      <div className="flex justify-between items-center">
                        <span className="text-sm font-semibold text-slate-600">UPI ID / Phone</span>
                        <span className="text-sm font-extrabold text-blue-900">+91 99964 09052</span>
                      </div>
                      <div className="flex justify-between items-center text-xs">
                        <span className="text-slate-500">Beneficiary Name</span>
                        <span className="font-bold text-slate-700">American Institute</span>
                      </div>
                    </div>
                  </div>

                  {/* PayPal Option */}
                  <div className="mb-8">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-3 text-left">International Options</p>
                    <button 
                      onClick={() => {
                        // Simulate opening PayPal
                        window.open('https://www.paypal.com/paypalme/americaninstitute', '_blank');
                        // Then prompt for transaction ID
                      }}
                      className="flex items-center justify-center gap-2 w-full py-3.5 bg-[#0070ba] text-white rounded-2xl font-bold hover:bg-[#005ea6] transition-all shadow-md group"
                    >
                      <div className="flex items-baseline gap-1">
                        <span className="italic font-extrabold text-lg">Pay</span>
                        <span className="italic font-extrabold text-lg opacity-80">Pal</span>
                      </div>
                    </button>
                    <p className="mt-2 text-[10px] text-slate-400 font-medium">Safe & Secure Global Payments</p>
                  </div>

                  <div className="space-y-4">
                    <div className="relative">
                      <input 
                        type="text" 
                        placeholder="Enter Transaction ID / UTR"
                        value={paymentConfig.transactionId}
                        onChange={(e) => setPaymentConfig(prev => ({ ...prev, transactionId: e.target.value }))}
                        className="w-full px-6 py-4 rounded-2xl bg-slate-50 border-transparent focus:border-blue-500 focus:bg-white transition-all font-semibold outline-hidden text-center"
                      />
                    </div>
                    
                    <button 
                      onClick={handleVerifyPayment}
                      disabled={!paymentConfig.transactionId || paymentConfig.isVerifying}
                      className="w-full py-4 bg-blue-900 text-white rounded-2xl font-extrabold text-lg shadow-xl shadow-blue-900/20 hover:bg-blue-800 disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-2"
                    >
                      {paymentConfig.isVerifying ? (
                        <>
                          <div className="w-5 h-5 border-3 border-white/30 border-t-white rounded-full animate-spin" />
                          Verifying...
                        </>
                      ) : (
                        'Verify & Unlock Card'
                      )}
                    </button>
                    
                    <button 
                      onClick={() => setPaymentConfig(prev => ({ ...prev, showDialog: false }))}
                      className="text-slate-400 text-sm font-bold hover:text-slate-600 transition-colors"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* Course Payment Dialog */}
        <AnimatePresence>
          {coursePaymentConfig.showDialog && coursePaymentConfig.selectedCourse && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-6">
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setCoursePaymentConfig(prev => ({ ...prev, showDialog: false }))}
                className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
              />
              <motion.div 
                initial={{ opacity: 0, scale: 0.9, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: 20 }}
                className="relative w-full max-w-lg bg-white rounded-[2.5rem] shadow-2xl overflow-hidden z-20"
              >
                <div className="p-8 md:p-10">
                  <button 
                    onClick={() => setCoursePaymentConfig(prev => ({ ...prev, showDialog: false }))}
                    className="absolute top-6 right-6 p-2 rounded-full hover:bg-slate-100 transition-colors"
                  >
                    <X className="w-5 h-5 text-slate-400" />
                  </button>

                  {!coursePaymentConfig.verified ? (
                    <div>
                      <div className="flex items-center gap-4 mb-6">
                        <div className="p-4 rounded-2xl bg-blue-50 text-blue-600">
                          {coursePaymentConfig.selectedCourse.icon}
                        </div>
                        <div>
                          <span className="text-[10px] font-bold text-blue-600 uppercase tracking-widest block mb-0.5">Enrollment & Secure Payment</span>
                          <h3 className="text-2xl font-display font-extrabold text-slate-900">{coursePaymentConfig.selectedCourse.title}</h3>
                        </div>
                      </div>

                      <p className="text-slate-500 mb-6 text-sm leading-relaxed">
                        Secure your seat instantly. Complete the token payment or full enrollment directly to the institute's unified payment number.
                      </p>

                      <div className="mb-6">
                        <label className="text-xs font-bold uppercase tracking-widest text-slate-400 block mb-3">Choose Payment Option</label>
                        <div className="grid grid-cols-3 gap-3">
                          {[
                            { label: 'Token Booking', val: '1500' },
                            { label: 'Installment', val: '3000' },
                            { label: 'Full Course', val: '5500' }
                          ].map((option) => (
                            <button
                              key={option.val}
                              type="button"
                              onClick={() => setCoursePaymentConfig(prev => ({ ...prev, amount: option.val }))}
                              className={`p-3 rounded-2xl border text-center transition-all flex flex-col items-center justify-center ${
                                coursePaymentConfig.amount === option.val
                                  ? 'border-blue-600 bg-blue-50/50 text-blue-900 font-extrabold shadow-sm shadow-blue-500/5'
                                  : 'border-slate-100 bg-white text-slate-600 hover:bg-slate-50'
                              }`}
                            >
                              <span className="text-[10px] block font-semibold text-slate-400 uppercase tracking-tight leading-none mb-1">{option.label}</span>
                              <span className="text-sm font-bold">₹{option.val}</span>
                            </button>
                          ))}
                        </div>
                      </div>

                      <div className="bg-slate-50 rounded-3xl p-6 mb-6 border border-slate-100/80">
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-3">Instant Deposit Credentials</p>
                        <div className="space-y-4">
                          {/* Mobile UPI launcher */}
                          <a 
                            href={`upi://pay?pa=9996409052@upi&pn=American%20Institute&am=${coursePaymentConfig.amount}&cu=INR&tn=Enrollment%20${encodeURIComponent(coursePaymentConfig.selectedCourse.title)}`}
                            className="flex items-center justify-center gap-3 w-full py-3.5 bg-blue-600 text-white rounded-2xl font-extrabold hover:bg-blue-700 transition-all shadow-md md:hidden"
                          >
                            <Zap className="w-4 h-4 fill-white" />
                            Pay ₹{coursePaymentConfig.amount} with UPI App
                          </a>

                          <div className="hidden md:block text-center py-2 px-4 bg-blue-50/50 rounded-xl border border-blue-100/50 mb-4">
                            <p className="text-[10px] font-bold text-blue-800 uppercase tracking-wide">Mobile Scanning / UPI</p>
                            <p className="text-xs text-blue-900/60 font-medium">Scan QR or transfer selected amount using any UPI application</p>
                          </div>

                          <div className="flex justify-between items-center bg-white p-3 rounded-xl border border-slate-100">
                            <div>
                              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wide">UPI ID / Number</p>
                              <p className="text-sm font-bold text-slate-900">9996409052@upi</p>
                            </div>
                            <button 
                              onClick={handleCopyUPI}
                              className="p-2.5 rounded-lg bg-slate-50 hover:bg-blue-50 text-slate-500 hover:text-blue-600 transition-colors flex items-center gap-1.5 text-xs font-bold"
                            >
                              {coursePaymentConfig.copied ? (
                                <span className="text-emerald-600 font-bold">Copied!</span>
                              ) : (
                                <>
                                  <Copy className="w-3.5 h-3.5" />
                                  Copy UPI ID
                                </>
                              )}
                            </button>
                          </div>

                          <div className="flex justify-between items-center text-xs px-1">
                            <span className="text-slate-500">Beneficiary Name</span>
                            <span className="font-bold text-slate-700">American Institute (Manpal Kinha)</span>
                          </div>
                        </div>
                      </div>

                      <div className="space-y-3">
                        <input 
                          type="text" 
                          placeholder="Enter Transaction ID / UTR"
                          value={coursePaymentConfig.transactionId}
                          onChange={(e) => setCoursePaymentConfig(prev => ({ ...prev, transactionId: e.target.value }))}
                          className="w-full px-6 py-4 rounded-2xl bg-slate-50 border-transparent focus:border-blue-500 focus:bg-white transition-all font-semibold outline-hidden text-center text-sm"
                        />
                        
                        <button 
                          onClick={handleVerifyCoursePayment}
                          disabled={!coursePaymentConfig.transactionId || coursePaymentConfig.isVerifying}
                          className="w-full py-4 bg-slate-900 hover:bg-slate-800 text-white rounded-2xl font-extrabold text-base shadow-xl disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-2"
                        >
                          {coursePaymentConfig.isVerifying ? (
                            <>
                              <div className="w-5 h-5 border-3 border-white/30 border-t-white rounded-full animate-spin" />
                              Verifying Transaction...
                            </>
                          ) : (
                            'Verify & Submit Enrollment'
                          )}
                        </button>
                      </div>
                    </div>
                  ) : (
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="text-center py-6"
                    >
                      <div className="w-20 h-20 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto mb-6">
                        <CheckCircle2 className="w-10 h-10" />
                      </div>
                      <h3 className="text-2xl font-display font-extrabold text-slate-900 mb-2">Enrollment Submitted!</h3>
                      <p className="text-sm text-slate-500 mb-8 max-w-sm mx-auto">
                        Your transaction <span className="font-bold text-slate-800">{coursePaymentConfig.transactionId}</span> of <span className="font-bold text-emerald-600">₹{coursePaymentConfig.amount}</span> has been securely recorded. 
                      </p>

                      <div className="space-y-4">
                        <a 
                          href={`https://wa.me/919996409052?text=Hello%20American%20Institute%2C%20I%20have%20completed%20the%20payment%20of%20INR%20${coursePaymentConfig.amount}%20for%20the%20${encodeURIComponent(coursePaymentConfig.selectedCourse.title)}%20course.%20Transaction%20ID%3A%20${coursePaymentConfig.transactionId}.%20Please%20confirm%20my%20enrollment!`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center justify-center gap-2 w-full py-4 bg-[#25D366] text-white rounded-2xl font-extrabold text-lg shadow-xl shadow-green-500/15 hover:bg-[#20ba5a] transition-all"
                        >
                          <MessageCircle className="w-5 h-5 fill-white" />
                          Share Receipt on WhatsApp
                        </a>

                        <button 
                          onClick={() => setCoursePaymentConfig(prev => ({ ...prev, showDialog: false }))}
                          className="text-slate-400 hover:text-slate-600 font-bold text-sm transition-all"
                        >
                          Close Window
                        </button>
                      </div>
                    </motion.div>
                  )}
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-24 relative">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid lg:grid-cols-12 gap-16">
            <div className="lg:col-span-5">
              <h2 className="text-4xl font-display font-extrabold mb-8">Ready to Start?</h2>
              <p className="text-lg text-slate-500 mb-12">
                Visit us or drop a message to get a free demo class and personalized roadmap for your English journey.
              </p>

              <div className="space-y-8">
                <motion.div 
                  initial={{ opacity: 0, x: -30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, type: "spring", stiffness: 100, damping: 15 }}
                  className="flex gap-6 hover:translate-x-1 transition-transform cursor-pointer"
                >
                  <div className="w-14 h-14 rounded-2xl bg-slate-50 flex items-center justify-center text-blue-600 shadow-sm border border-slate-100">
                    <MapPin className="w-6 h-6 animate-pulse" />
                  </div>
                  <div>
                    <h5 className="font-bold text-slate-700 text-sm uppercase tracking-widest mb-1">Our Location</h5>
                    <p className="font-bold">Jhajjar Road, Near Vaish Girls School, Rohtak</p>
                    <p className="text-slate-500 text-sm">Opposite Union Bank, Haryana 124001</p>
                  </div>
                </motion.div>

                <motion.div 
                  initial={{ opacity: 0, x: -30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.1, duration: 0.6, type: "spring", stiffness: 100, damping: 15 }}
                  className="flex gap-6 hover:translate-x-1 transition-transform cursor-pointer"
                >
                  <div className="w-14 h-14 rounded-2xl bg-slate-50 flex items-center justify-center text-blue-600 shadow-sm border border-slate-100">
                    <Clock className="w-6 h-6" />
                  </div>
                  <div>
                    <h5 className="font-bold text-slate-700 text-sm uppercase tracking-widest mb-1">Working Hours</h5>
                    <p className="font-bold">Mon - Sat: 7 AM - 7 PM</p>
                    <p className="text-slate-500 text-sm">Sunday: Closed</p>
                  </div>
                </motion.div>

                <motion.div 
                  initial={{ opacity: 0, x: -30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.2, duration: 0.6, type: "spring", stiffness: 100, damping: 15 }}
                  className="flex gap-6 hover:translate-x-1 transition-transform cursor-pointer"
                >
                  <div className="w-14 h-14 rounded-2xl bg-slate-50 flex items-center justify-center text-blue-600 shadow-sm border border-slate-100">
                    <Phone className="w-6 h-6 animate-bounce" />
                  </div>
                  <div>
                    <h5 className="font-bold text-slate-700 text-sm uppercase tracking-widest mb-1">Direct Call</h5>
                    <p className="font-bold">+91 99964 09052</p>
                    <p className="text-slate-500 text-sm">Call for instant inquiry</p>
                  </div>
                </motion.div>
              </div>
            </div>

            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 30 }}
              whileInView={{ opacity: 1, scale: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.8, type: "spring", stiffness: 85, damping: 14 }}
              className="lg:col-span-7 bg-white p-10 rounded-[2.5rem] shadow-2xl border border-slate-50 relative z-10"
            >
              <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-widest text-slate-400 ml-1">Full Name</label>
                    <input 
                      type="text" 
                      placeholder="John Doe" 
                      className="w-full px-6 py-4 rounded-2xl bg-slate-50 border-transparent focus:border-blue-500 focus:bg-white focus:ring-0 transition-all font-semibold outline-hidden"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-widest text-slate-400 ml-1">Phone Number</label>
                    <input 
                      type="tel" 
                      placeholder="+91 ...." 
                      className="w-full px-6 py-4 rounded-2xl bg-slate-50 border-transparent focus:border-blue-500 focus:bg-white focus:ring-0 transition-all font-semibold outline-hidden"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest text-slate-400 ml-1">Course Interested In</label>
                  <select className="w-full px-6 py-4 rounded-2xl bg-slate-50 border-transparent focus:border-blue-500 focus:bg-white focus:ring-0 transition-all font-semibold appearance-none outline-hidden">
                    <option>Spoken English</option>
                    <option>IELTS</option>
                    <option>PTE</option>
                    <option>OET</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest text-slate-400 ml-1">Your Message</label>
                  <textarea 
                    rows={4} 
                    placeholder="How can we help you?"
                    className="w-full px-6 py-4 rounded-2xl bg-slate-50 border-transparent focus:border-blue-500 focus:bg-white focus:ring-0 transition-all font-semibold outline-hidden"
                  />
                </div>
                <button 
                  className="w-full py-5 bg-blue-900 text-white rounded-2xl font-extrabold text-lg shadow-xl shadow-blue-900/20 hover:bg-blue-800 hover:scale-[1.01] active:scale-[0.99] transition-all"
                  id="contact-submit"
                >
                  Send Message
                </button>
              </form>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-12 mb-12 border-b border-white/5 pb-12">
            <div className="md:col-span-2">
              <div className="font-display font-extrabold text-3xl tracking-tighter mb-6">
                AMERICAN<span className="text-blue-500">.</span>INSTITUTE
              </div>
              <p className="text-slate-400 max-w-sm leading-relaxed mb-8">
                Empowering the youth of Rohtak with international standard English communication skills since 2012. Join us to find your voice.
              </p>
              <div className="flex gap-4">
                {/* Social icons could go here */}
                <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-blue-600 transition-colors cursor-pointer"><Globe className="w-5 h-5" /></div>
                <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-blue-600 transition-colors cursor-pointer"><Mail className="w-5 h-5" /></div>
                <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-blue-600 transition-colors cursor-pointer"><BookOpen className="w-5 h-5" /></div>
              </div>
            </div>

            <div>
              <h5 className="font-bold uppercase tracking-widest text-xs text-blue-500 mb-6">Quick Links</h5>
              <ul className="space-y-4">
                <li><a href="#about" className="text-slate-400 hover:text-white transition-colors">About Us</a></li>
                <li><a href="#courses" className="text-slate-400 hover:text-white transition-colors">Our Courses</a></li>
                <li><a href="#why-us" className="text-slate-400 hover:text-white transition-colors">Testimonials</a></li>
                <li><a href="#contact" className="text-slate-400 hover:text-white transition-colors">Admission</a></li>
              </ul>
            </div>

            <div>
              <h5 className="font-bold uppercase tracking-widest text-xs text-blue-500 mb-6">Support</h5>
              <ul className="space-y-4">
                <li><a href="#" className="text-slate-400 hover:text-white transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="text-slate-400 hover:text-white transition-colors">Terms of Service</a></li>
                <li><a href="#" className="text-slate-400 hover:text-white transition-colors">FAQ</a></li>
              </ul>
            </div>
          </div>

          <div className="flex flex-col md:row justify-between items-center gap-6">
            <p className="text-slate-500 text-sm">
              © {new Date().getFullYear()} American Institute Rohtak. All rights reserved.
            </p>
            <p className="text-slate-500 text-sm">
              Designed for Excellence.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

